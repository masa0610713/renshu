INSERT INTO users (username, password, roles) VALUES
('admin', 'admin_password_hash', 'category_admin,thread_admin'),
('user1', 'user1_password_hash', 'user');

INSERT INTO categories (name) VALUES
('カテゴリー1'),
('カテゴリー2'),
('カテゴリー3'),
('カテゴリー4'),
('カテゴリー5');

INSERT INTO threads (category_id, user_id, title, content) VALUES
(1, 1, 'カテゴリー1のスレッド1', 'カテゴリー1のスレッド1の内容'),
(1, 1, 'カテゴリー1のスレッド2', 'カテゴリー1のスレッド2の内容'),
(2, 1, 'カテゴリー2のスレッド1', 'カテゴリー2のスレッド1の内容'),
(3, 1, 'カテゴリー3のスレッド1', 'カテゴリー3のスレッド1の内容'),
(4, 1, 'カテゴリー4のスレッド1', 'カテゴリー4のスレッド1の内容');

INSERT INTO comments (thread_id, user_id, content) VALUES
(1, 1, 'カテゴリー1のスレッド1のコメント1'),
(1, 1, 'カテゴリー1のスレッド1のコメント2'),
(2, 1, 'カテゴリー1のスレッド2のコメント1'),
(3, 1, 'カテゴリー2のスレッド1のコメント1'),
(4, 1, 'カテゴリー3のスレッド1のコメント1');