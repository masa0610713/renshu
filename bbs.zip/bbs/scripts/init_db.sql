DROP DATABASE IF EXISTS bbs_app;


-- データベースの作成
CREATE DATABASE bbs_app;

-- データベースに接続
\c bbs_app;

-- テーブルの作成
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL,
    roles VARCHAR(255) DEFAULT 'user',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE categories (
    id SERIAL PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE threads (
    id SERIAL PRIMARY KEY,
    category_id INT NOT NULL,
    user_id INT NOT NULL,
    title VARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE comments (
    id SERIAL PRIMARY KEY,
    thread_id INT NOT NULL,
    user_id INT NOT NULL,
    content TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (thread_id) REFERENCES threads(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- 初期データの挿入
/*
INSERT INTO users (username, password, roles) VALUES
('admin', 'admin_password_hash', 'category_admin,thread_admin'),
('user1', 'user1_password_hash', 'user');

INSERT INTO categories (name) VALUES
('カテゴリー1'),
('カテゴリー2'),
('カテゴリー3'),
('カテゴリー4'),
('カテゴリー5');

INSERT INTO threads (category_id, user_id, title, content) VALUES
(1, 1, 'カテゴリー1のスレッド1', 'カテゴリー1のスレッド1の内容'),
(1, 1, 'カテゴリー1のスレッド2', 'カテゴリー1のスレッド2の内容'),
(2, 1, 'カテゴリー2のスレッド1', 'カテゴリー2のスレッド1の内容'),
(3, 1, 'カテゴリー3のスレッド1', 'カテゴリー3のスレッド1の内容'),
(4, 1, 'カテゴリー4のスレッド1', 'カテゴリー4のスレッド1の内容');

INSERT INTO comments (thread_id, user_id, content) VALUES
(1, 1, 'カテゴリー1のスレッド1のコメント1'),
(1, 1, 'カテゴリー1のスレッド1のコメント2'),
(2, 1, 'カテゴリー1のスレッド2のコメント1'),
(3, 1, 'カテゴリー2のスレッド1のコメント1'),
(4, 1, 'カテゴリー3のスレッド1のコメント1');

*/