<?php
session_start();

// ユーザーロールの確認
if (!isset($_SESSION['user_id'])) {
    echo "アクセス権限がありません。";
    exit;
}

require_once '../includes/db.php';

$userId = $_SESSION['user_id'];
$stmt = $pdo->prepare('SELECT roles FROM users WHERE id = :id');
$stmt->execute(['id' => $userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user || $user['roles'] !== 'C') {
    echo "アクセス権限がありません。";
    exit;
}

require_once '../includes/db.php';

// カテゴリーを取得
$categoryStmt = $pdo->query('SELECT id, name FROM categories');
$categories = $categoryStmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>カテゴリー管理</title>
    <link rel="stylesheet" href="../css/common.css">
</head>
<body>
    <h1>カテゴリー管理</h1>
    <form action="../actions/manage_categories.php" method="post">
        <input type="text" name="category_name" placeholder="カテゴリー名" required>
        <button type="submit" name="action" value="add">カテゴリーを追加</button>
    </form>

    <h2>現在のカテゴリー一覧</h2>
    <ul>
        <?php foreach ($categories as $category): ?>
            <li>
                <?= htmlspecialchars($category['name']) ?>
                <form action="../actions/manage_categories.php" method="post" style="display:inline;">
                    <input type="hidden" name="category_id" value="<?= $category['id'] ?>">
                    <button type="submit" name="action" value="delete">削除</button>
                </form>
            </li>
        <?php endforeach; ?>
    </ul>
</body>
</html>