<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>スレッド書き込み</title>
    <link rel="stylesheet" href="../css/common.css">
</head>
<body>
    <h1>新しいスレッドを作成</h1>
    <form action="../actions/create_thread.php" method="post">
        <input type="text" name="title" placeholder="スレッドタイトル" required>
        <textarea name="content" placeholder="内容" required></textarea>
        <button type="submit">スレッドを作成</button>
    </form>
</body>
</html>