<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>スレッド管理</title>
    <link rel="stylesheet" href="../css/common.css">
</head>
<body>
    <h1>スレッド管理</h1>
    <!-- スレッドの編集・削除機能 -->
</body>
</html>