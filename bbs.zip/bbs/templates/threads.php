<?php
// ... DB接続とスレッド取得のコード ...
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>スレッド選択</title>
    <link rel="stylesheet" href="../css/common.css">
</head>
<body>
    <h1>スレッド選択</h1>
    <ul>
        <?php foreach ($threads as $thread): ?>
            <li><a href="thread.php?thread=<?= $thread['id'] ?>"><?= htmlspecialchars($thread['title']) ?></a></li>
        <?php endforeach; ?>
    </ul>
</body>
</html>