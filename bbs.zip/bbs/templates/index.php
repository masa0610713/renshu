<?php
require_once '../includes/db.php';
session_start();

// カテゴリーを取得
$categoryStmt = $pdo->query('SELECT id, name FROM categories');
$categories = $categoryStmt->fetchAll(PDO::FETCH_ASSOC);

// ログインしているか確認
$isLoggedIn = false;
if (isset($_SESSION['user_id'])) {
    $stmt = $pdo->prepare('SELECT username FROM users WHERE id = :id');
    $stmt->execute(['id' => $_SESSION['user_id']]);
    $user = $stmt->fetch();
    if ($user) {
        $_SESSION['username'] = $user['username'];
        $isLoggedIn = true;
    }
}
?>
<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>BBS トップページ</title>
    <link rel="stylesheet" href="../css/common.css">
    <link rel="stylesheet" href="../css/layout.css">
    <style>
        .button-container {
            position: absolute;
            top: 10px;
            right: 10px;
        }
        .button-container button {
            margin-left: 10px;
            padding: 10px 20px;
            background-color: #007bff;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .button-container button:hover {
            background-color: #0056b3;
        }
        .comment-section {
            margin-top: 20px;
        }
        .comment-section textarea {
            width: 100%;
            height: 100px;
        }
        .comment-section button {
            margin-top: 10px;
            padding: 10px 20px;
            background-color: #28a745;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        .comment-section button:hover {
            background-color: #218838;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="button-container">
            <?php if ($isLoggedIn): ?>
                <span>ようこそ、<?= htmlspecialchars($_SESSION['username']) ?>さん</span>
                <button onclick="location.href='../actions/logout.php'">ログアウト</button>
            <?php else: ?>
                <button onclick="location.href='login.php'">ログイン</button>
                <button onclick="location.href='regist_user.php'">新規登録</button>
            <?php endif; ?>
        </div>

        <div class="left-pane">
            <h2>カテゴリー一覧</h2>
            <ul id="category-list">
                <?php foreach ($categories as $category): ?>
                    <li onclick="loadThreads(<?= $category['id'] ?>)"><?= htmlspecialchars($category['name']) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
        <div class="right-pane">
            <div class="threads-pane">
                <h2>スレッド一覧</h2>
                <ul id="thread-list">
                    <!-- スレッドはJavaScriptで動的に追加 -->
                </ul>
            </div>
            <div class="content-pane">
                <h2>スレッド内容</h2>
                <div id="thread-content">
                    <!-- スレッド内容はJavaScriptで動的に追加 -->
                </div>
                <?php if ($isLoggedIn): ?>
                <div class="comment-section" id="comment-section" style="display: none;">
                    <h3>コメントを残す</h3>
                    <textarea id="comment-text" placeholder="コメントを入力してください..."></textarea>
                    <button onclick="submitComment()">コメントを投稿</button>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <script>
        let selectedThreadId = null;

        function loadThreads(categoryId) {
            fetch(`../actions/get_threads.php?category_id=${categoryId}`)
                .then(response => response.json())
                .then(threads => {
                    const threadList = document.getElementById('thread-list');
                    threadList.innerHTML = ''; // スレッド一覧をクリア
                    threads.forEach(thread => {
                        const li = document.createElement('li');
                        li.textContent = thread.title;
                        li.onclick = () => {
                            loadThreadContent(thread.id);
                            selectedThreadId = thread.id;
                            document.getElementById('comment-section').style.display = 'block';
                        };
                        threadList.appendChild(li);
                    });
                });
        }

        function loadThreadContent(threadId) {
            fetch(`../actions/get_thread_content.php?thread_id=${threadId}`)
            .then(response => response.json())
            .then(data => {
                const threadContent = document.getElementById('thread-content');
                threadContent.innerHTML = `<h3>${data.title}</h3><p>${data.content}</p>`; // スレッド内容を表示

                const comments = data.comments;
                let commentsHtml = '<h4>コメント一覧</h4><ul>';
                comments.forEach((comment, index) => {
                    commentsHtml += `<li>${index + 1}. ${comment.content}</li>`;
                });
                commentsHtml += '</ul>';
                threadContent.innerHTML += commentsHtml;
            });
        }

        function submitComment() {
            const commentText = document.getElementById('comment-text').value;
            if (!commentText) {
                alert('コメントを入力してください。');
                return;
            }

            fetch('../actions/submit_comment.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ threadId: selectedThreadId, comment: commentText })
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert('コメントが投稿されました。');
                    document.getElementById('comment-text').value = '';
                } else {
                    alert('コメントの投稿に失敗しました。');
                }
            });
        }
    </script>
</body>
</html>