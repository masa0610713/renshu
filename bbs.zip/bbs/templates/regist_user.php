<!DOCTYPE html>
<html lang="ja">
<head>
    <meta charset="UTF-8">
    <title>ユーザー登録</title>
    <script>
        async function registerUser(event) {
            event.preventDefault();
            const username = document.getElementById('username').value;
            const password = document.getElementById('password').value;
            const roles = 'user'; // デフォルトの役割

            const response = await fetch('../actions/register.php', { // パスを修正
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ username, password, roles })
            });

            if (response.ok) {
                alert('登録が完了しました！');
                window.location.href = 'login.php'; // ログインページにリダイレクト
            } else {
                alert('登録に失敗しました。もう一度お試しください。');
            }
        }
    </script>
</head>
<body>
    <h1>ユーザー登録</h1>
    <form onsubmit="registerUser(event)">
        <label for="username">ユーザー名:</label>
        <input type="text" id="username" name="username" required><br>
        <label for="password">パスワード:</label>
        <input type="password" id="password" name="password" required><br>
        <button type="submit">登録</button>
    </form>
</body>
</html>