<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';

requireLogin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $comment = $_POST['comment'];
    $thread_id = $_POST['thread_id'];

    $stmt = $pdo->prepare('INSERT INTO comments (thread_id, user_id, content) VALUES (:thread_id, :user_id, :content)');
    $stmt->execute([
        'thread_id' => $thread_id,
        'user_id' => $_SESSION['user_id'],
        'content' => $comment
    ]);

    header('Location: ../templates/thread.php?thread=' . $thread_id);
}
?>