<?php
header('Content-Type: application/json');

require_once '../includes/db.php'; // データベース接続

session_start();

if (!isset($_SESSION['user_id'])) {
    http_response_code(403);
    echo json_encode(['success' => false, 'message' => 'ログインが必要です。']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);

if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => '無効なJSONです。']);
    exit;
}

$threadId = $input['threadId'];
$comment = $input['comment'];
$userId = $_SESSION['user_id'];

try {
    $stmt = $pdo->prepare('INSERT INTO comments (thread_id, user_id, content, created_at) VALUES (:thread_id, :user_id, :comment, now())');
    $stmt->execute(['thread_id' => $threadId, 'user_id' => $userId, 'comment' => $comment]);

    echo json_encode(['success' => true]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'コメントの投稿に失敗しました。']);
}