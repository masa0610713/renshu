<?php
require_once '../includes/db.php';
require_once '../includes/auth.php';

requireLogin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = $_POST['title'];
    $content = $_POST['content'];
    $category_id = $_POST['category_id'];

    $stmt = $pdo->prepare('INSERT INTO threads (category_id, user_id, title, content) VALUES (:category_id, :user_id, :title, :content)');
    $stmt->execute([
        'category_id' => $category_id,
        'user_id' => $_SESSION['user_id'],
        'title' => $title,
        'content' => $content
    ]);

    header('Location: ../templates/threads.php?category=' . $category_id);
}
?>