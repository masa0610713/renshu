<?php
require_once '../includes/db.php';

header('Content-Type: application/json');

if (isset($_GET['category_id'])) {
    $categoryId = (int)$_GET['category_id'];

    $stmt = $pdo->prepare('SELECT id, title FROM threads WHERE category_id = :category_id');
    $stmt->execute(['category_id' => $categoryId]);
    $threads = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($threads);
} else {
    echo json_encode([]);
}
?>