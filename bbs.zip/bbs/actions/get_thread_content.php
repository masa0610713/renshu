<?php
header('Content-Type: application/json');

require_once '../includes/db.php';

$threadId = $_GET['thread_id'];

try {
    // スレッドの内容を取得
    $stmt = $pdo->prepare('SELECT title, content FROM threads WHERE id = :thread_id');
    $stmt->execute(['thread_id' => $threadId]);
    $thread = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$thread) {
        echo json_encode(['error' => 'スレッドが見つかりません。']);
        exit;
    }

    // コメントを取得
    $stmt = $pdo->prepare('SELECT content FROM comments WHERE thread_id = :thread_id ORDER BY created_at ASC');
    $stmt->execute(['thread_id' => $threadId]);
    $comments = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode(['title' => $thread['title'], 'content' => $thread['content'], 'comments' => $comments]);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['error' => 'データの取得に失敗しました。']);
}