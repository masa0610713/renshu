<?php
session_start();

// ユーザーロールの確認
if (!isset($_SESSION['user_id'])) {
    echo "アクセス権限がありません。";
    exit;
}

require_once '../includes/db.php';

$userId = $_SESSION['user_id'];
$stmt = $pdo->prepare('SELECT roles FROM users WHERE id = :id');
$stmt->execute(['id' => $userId]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$user || $user['roles'] !== 'C') {
    echo "アクセス権限がありません。";
    exit;
}
require_once '../includes/db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];

    if ($action === 'add' && !empty($_POST['category_name'])) {
        $categoryName = $_POST['category_name'];

        try {
            $stmt = $pdo->prepare('INSERT INTO categories (name) VALUES (:name)');
            $stmt->execute(['name' => $categoryName]);
            header('Location: ../templates/manage_categories.php');
            exit;
        } catch (PDOException $e) {
            echo "カテゴリーの追加に失敗しました: " . $e->getMessage();
        }
    } elseif ($action === 'delete' && !empty($_POST['category_id'])) {
        $categoryId = $_POST['category_id'];

        try {
            $stmt = $pdo->prepare('DELETE FROM categories WHERE id = :id');
            $stmt->execute(['id' => $categoryId]);
            header('Location: ../templates/manage_categories.php');
            exit;
        } catch (PDOException $e) {
            echo "カテゴリーの削除に失敗しました: " . $e->getMessage();
        }
    }
}