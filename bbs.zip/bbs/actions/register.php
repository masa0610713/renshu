<?php
header('Content-Type: application/json');

require_once '../includes/db.php'; // db.phpをインクルード

$input = json_decode(file_get_contents('php://input'), true);

if (json_last_error() !== JSON_ERROR_NONE) {
    http_response_code(400);
    echo json_encode(['error' => 'Invalid JSON']);
    exit;
}

$username = $input['username'];
$password = $input['password'];
$roles = $input['roles'];

// パスワードのハッシュ化
$hashed_password = password_hash($password, PASSWORD_BCRYPT);

try {
    // ユーザーの挿入
    $stmt = $pdo->prepare('INSERT INTO users (username, password, roles) VALUES (:username, :password, :roles)');
    $stmt->execute(['username' => $username, 'password' => $hashed_password, 'roles' => $roles]);

    echo json_encode(['id' => $pdo->lastInsertId()]);
} catch (PDOException $e) {
    http_response_code(400);
    echo json_encode(['error' => $e->getMessage()]);
}